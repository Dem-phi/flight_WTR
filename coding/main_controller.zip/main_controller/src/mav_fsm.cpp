#include "mav_fsm.h"
#include "math.h"
using namespace wtr;
using namespace std;

// ========================================== POSE_MODE =========================================
void MavFsmNode::pos_mode(){
    if(cnt++ > 50.0*mode_info_interval)// make the information frequency reduce to 1Hz.
    {
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][POSE]:-------------- \033[33m POSE CONTROL WORKING \033[0m-------------------");
    }
    target_pose_.header.frame_id="body";
    target_pose_.header.stamp = ros::Time::now();
    Pub_remap_msg(plan_target);
    if (plan_target == target_A){
        remap_target_state.data = "target_A";
        target_pose_.pose = goalPose.A_pose;
        goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
        local_pos_pub_.publish(target_pose_);
        if(!if_in_tolerance(goalPose.error_pose))
            return;
        if(test_times <= poseMode_test_times){test_times++; return;}
        ROS_INFO("Reach \033[35m A position\033[0m.");
        InitAndSwitchMode(&test_times, &work_state_);
        return;
    }
    else if(plan_target == target_B){
        remap_target_state.data = "target_B";
        target_pose_.pose = goalPose.B_pose;
        goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
        local_pos_pub_.publish(target_pose_);
        if(!if_in_tolerance(goalPose.error_pose))
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        ROS_INFO("Reach \033[35m B position\033[0m.");
        InitAndSwitchMode(&test_times, &work_state_);
        return;
    }
    else if(plan_target == target_C){
        remap_target_state.data = "target_C";
        target_pose_.pose = goalPose.C_pose;
        goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
        local_pos_pub_.publish(target_pose_);
        if(!if_in_tolerance(goalPose.error_pose))
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        ROS_INFO("Reach \033[35m C position\033[0m.");
        InitAndSwitchMode(&test_times, &work_state_);
        return;
    }
    else if(plan_target == back){
        remap_target_state.data = "back";
        target_pose_.pose = goalPose.H_pose;
        goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
        local_pos_pub_.publish(target_pose_);
        if(!if_in_tolerance(goalPose.error_pose))
            return;
        ROS_INFO("UAV is \033[34mback\033[0m");
        InitAndSwitchMode(&test_times, &work_state_);
        return;
    }

}

// ========================================== VELOCITY_MODE =========================================
void MavFsmNode::vel_mode() {
    if (cnt++ > 50.0*mode_info_interval){
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][VELOCITY]:-------------- \033[33m VELOCITY CONTROL WORKING \033[0m-------------------");
    }
    vel_signal_.header.stamp = ros::Time::now();
    vel_signal_.header.frame_id = "body";
    /* get the velocity of UAV */

    speed_pub_.publish(vel_signal_);
    if (plan_target == rc_control){
        return;
    }
    switch (plan_target) {
        case target_A:
            //turn off the t265 And set next relative position
            t265_ctl_state.data = false;
            t265_ctl_pub_.publish(t265_ctl_state);
            goalPose.B_pose = World2Relative(goalPose.B_pose, goalPose.A_pose);
            InitAndSwitchMode(&test_times, &work_state_);
            break;
        case target_B:
            t265_ctl_state.data = false;
            t265_ctl_pub_.publish(t265_ctl_state);
            goalPose.C_pose = World2Relative(goalPose.C_pose, goalPose.B_pose);
            InitAndSwitchMode(&test_times, &work_state_);
            break;
        case target_C:
            t265_ctl_state.data = false;
            t265_ctl_pub_.publish(t265_ctl_state);
            goalPose.H_pose = World2Relative(goalPose.H_pose, goalPose.C_pose);
            InitAndSwitchMode(&test_times, &work_state_);
            break;
        case back:
            t265_ctl_state.data = false;
            t265_ctl_pub_.publish(t265_ctl_state);
            InitAndSwitchMode(&test_times, &work_state_);
            break;
    }

}

// ========================================== TAKEOFF_MODE =========================================
void MavFsmNode::takeoff_mode() {
    if(cnt++ > 50.0*mode_info_interval){
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][TAKEOFF]:--------------\033[36m TAKEOFF \033[0m-------------------");
    }
    takeoff_pose_.header.stamp = ros::Time::now();
    switch (plan_target) {
        case target_A:{
            target_pose_.pose = cur_pose_;
            target_pose_.pose.position.z += 1.0;
            goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
            local_pos_pub_.publish(takeoff_pose_);
            if(!if_in_tolerance(goalPose.error_pose))
                return;
            test_times++;
            if(test_times >= 50){
                local_pos_pub_.publish(takeoff_pose_);
                ROS_INFO("Plan to \033[34mA Area\033[0m");
                InitAndSwitchMode(&test_times, &work_state_);
                break;
            }
            break;
        }
        case target_B: {
            target_pose_.pose = cur_pose_;
            target_pose_.pose.position.z += 2.0;
            goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
            local_pos_pub_.publish(takeoff_pose_);
            if(!if_in_tolerance(goalPose.error_pose))
                return;
            test_times++;
            if(test_times >= 50){
                local_pos_pub_.publish(takeoff_pose_);
                ROS_INFO("Plan to \033[34mB Area\033[0m");
                InitAndSwitchMode(&test_times, &work_state_);
                break;
            }
            break;
        }
        case target_C: {
            target_pose_.pose = cur_pose_;
            target_pose_.pose.position.z += 2.0;
            goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
            local_pos_pub_.publish(takeoff_pose_);
            if(!if_in_tolerance(goalPose.error_pose))
                return;
            test_times++;
            if(test_times >= 50){
                local_pos_pub_.publish(takeoff_pose_);
                ROS_INFO("Plan to \033[34mC Area\033[0m");
                InitAndSwitchMode(&test_times, &work_state_);
                break;
            }
            break;
        }
        case back: {
            target_pose_.pose = cur_pose_;
            target_pose_.pose.position.z += 2.0;
            goalPose.error_pose = update_error(cur_pose_, target_pose_.pose);
            local_pos_pub_.publish(takeoff_pose_);
            if(!if_in_tolerance(goalPose.error_pose))
                return;
            ROS_INFO("Plan to \033[34mBack Home\033[0m");
            InitAndSwitchMode(&test_times, &work_state_);
            break;
        }
    }
}

// ========================================== LAND_MODE =========================================
void MavFsmNode::land_mode() {
    if(cnt++ > 50.0*mode_info_interval){
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][LAND]:--------------\033[32m LANDING \033[0m-------------------");
    }
    land_signal_.header.stamp = ros::Time::now();
    land_signal_.header.frame_id = "body";
    if (rc_msg_land_ < 1100){
        land_signal_.twist.linear.z = -0.3;
        speed_pub_.publish(land_signal_);
        return;
    }
    if(rc_msg_land_ > 1100){
        test_times++;
        switch (plan_target){
            case target_A: {
                land_signal_.twist.linear.z = -0.3;
                if(test_times >= 1 && if_on_ground==1){
                    // restart t265
                    t265_ctl_state.data = true;
                    t265_ctl_pub_.publish(t265_ctl_state);
                    servo_state.y = release_servo_B;
                    servo_pub_.publish(servo_state);
                }
                if(test_times>=100 && if_on_ground==1) {
                    takeoff_pose_.pose = cur_pose_; // position at A
                    InitAndSwitchMode(&test_times, &work_state_, &plan_target);
                }
                break;
            }
            case target_B: {
                land_signal_.twist.linear.z = -0.3;
                if(test_times >= 1 && if_on_ground==1){
                    // restart t265
                    t265_ctl_state.data = true;
                    t265_ctl_pub_.publish(t265_ctl_state);
                    servo_state.x = release_servo_A;
                    servo_pub_.publish(servo_state);
                }
                if(test_times>=100 && if_on_ground==1) {
                    takeoff_pose_.pose = cur_pose_; // position at B
                    InitAndSwitchMode(&test_times, &work_state_, &plan_target);
                }
                break;
            }
            case target_C: {
                land_signal_.twist.linear.z = -0.3;
                if(test_times >= 1 && if_on_ground==1){
                    // restart t265
                    t265_ctl_state.data = true;
                    t265_ctl_pub_.publish(t265_ctl_state);
                    servo_state.z = release_servo_C;
                    servo_pub_.publish(servo_state);
                }
                if(test_times>=100 && if_on_ground==1) {
                    takeoff_pose_.pose = cur_pose_; // position at C
                    InitAndSwitchMode(&test_times, &work_state_, &plan_target);
                }
                break;
            }
            case back:{
                land_signal_.twist.linear.z = -0.3;
                if(if_on_ground == 1){
                    work_state_ = waiting;
                }
                break;
            }
        }
    }
    speed_pub_.publish(land_signal_);
    return;
}

// ========================================== WAIT_MODE =========================================
void MavFsmNode::wait_mode() {
    if(cnt++ > 50.0*mode_info_interval)// make the information frequency reduce to 1Hz.
    {
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][WAITING]:--------------Waiting for command.-------------------");
    }
}

// Returns the circle's position and calculate a PID velocity
void MavFsmNode::visionCallback(const geometry_msgs::Vector3::ConstPtr &msg){
/*    circle_position.x = msg->x;
    circle_position.y = msg->y;

    vel_signal_.twist.linear.z = 0;
      Define the position PID
    vel_signal_.twist.linear.x = fp.k_position.x()*different_vector[0]-fp.i_position.x()*different_vector[2]*0.02+fp.k_velocity.x()*(different_vector[0] - different_vector[2])/0.02;
    vel_signal_.twist.linear.y = fp.k_position.y()*different_vector[1]-fp.i_position.y()*different_vector[3]*0.02+fp.k_velocity.y()*(different_vector[1] - different_vector[3])/0.02;
    vel_signal_.twist.linear.x /= 800.0;
    vel_signal_.twist.linear.y /= -800.0;

    different_vector[4] = different_vector[2];
    different_vector[5] = different_vector[3];
    different_vector[2] = different_vector[0];
    different_vector[3] = different_vector[1];

    *//* limit the max velocity *//*
    if(vel_signal_.twist.linear.x >= fp.limit_vel_max.x()){
        vel_signal_.twist.linear.x = fp.limit_vel_max.x();
    }
    else if(vel_signal_.twist.linear.x <= -fp.limit_vel_max.x())
    {
        vel_signal_.twist.linear.x = -fp.limit_vel_max.x();
    }
    if(vel_signal_.twist.linear.y >= fp.limit_vel_max.y()){
        vel_signal_.twist.linear.y = fp.limit_vel_max.y();
    }
    else if(vel_signal_.twist.linear.y <= -fp.limit_vel_max.y())
    {
        vel_signal_.twist.linear.y = -fp.limit_vel_max.y();
    }

    vel_signal_.twist.angular.x = 0;
    vel_signal_.twist.angular.y = 0;
    vel_signal_.twist.angular.z = 0;*/
}

// main loop function
void MavFsmNode::main_FSM(const ros::TimerEvent &) {
    if(!is_init_pose_) work_state_ = waiting;
    if(rc_msg_land_>1100 && rc_msg_land_<1500){
        work_state_ = land;
        land_signal_.twist.linear.z = -0.3;
        speed_pub_.publish(land_signal_);
        return;
    }
    // Auto take off
    /*
     * if(rc_msg_land_>1100 && change_state_times++>250 && if_on_ground == 1 && plan_target == target_A)
    {
        if(cur_state.mode!="OFFBOARD"){
            if(set_mode_client.call(offb_set_mode)&&
               offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enable");
            }
        }
        else if(!cur_state.armed){
            if( arming_client.call(arm_cmd) &&
                arm_cmd.response.success){
                ROS_INFO("Flight armed");
            }
        }
        change_state_times=0;
    }
    */
     switch (work_state_){
        case waiting: {
            wait_mode();break;
        }
        case takeoff: {
            takeoff_mode();break;
        }
        case land: {
            land_mode();break;
        }
        case pose:{
            pos_mode();break;
        }
        case velocity:{
            vel_mode();break;
        }
        default:{
            wait_mode();
        }
    }
}

void MavFsmNode::poseCallback(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    if(!is_init_pose_){
        init_pose_ = msg->pose;
        is_init_pose_ = true;
    }
    //protect
    if(msg->pose.position.z>2.5){
        work_state_ = land;
    }
    if(is_init_pose_){
        cur_pose_=msg->pose;
    }
}

void MavFsmNode::rcCallback(const mavros_msgs::RCInConstPtr &msg) {
    rc_msg_land_ = msg->channels[6];
    if(msg->channels[6] < 1100){
        work_state_  = velocity;
        /* In this mode, the UAV will control in manual mode */
        plan_target = rc_control;
        // update vel info
        vel_signal_.twist.linear.x = (msg->channels[1]-420)/420.0;
        vel_signal_.twist.linear.y = (msg->channels[2]-419)/419.0;
        vel_signal_.twist.linear.z = (msg->channels[0]-838)/838.0;
        vel_signal_.twist.angular.x = 0;
        vel_signal_.twist.angular.y = 0;
        vel_signal_.twist.angular.z = 0;
    }
    else if(msg->channels[6] > 1100 && msg->channels[6] < 1500){    // C开关mid 降落
        work_state_ = land;
    }
    else if(msg->channels[5] < 1500 && plan_target == target_A){ // 开关B向上
        work_state_= takeoff;
    }

}

void MavFsmNode::batCallback(const sensor_msgs::BatteryStateConstPtr &msg){
    if(msg->voltage<=16.0 && v_cnt >=50){
        ROS_INFO("Battery voltage is %.2f", msg->voltage);
        v_cnt = 0;
    }
    v_cnt++;
}

void MavFsmNode::extented_stateCallback(const mavros_msgs::ExtendedStateConstPtr &msg){
    if_on_ground = msg->landed_state;
}

void MavFsmNode::stateCallback(const mavros_msgs::StateConstPtr &msg) {
    cur_state = *msg;
}

// main func: initialize the parameters and start the timer 
MavFsmNode::MavFsmNode(ros::NodeHandle &nh) {
    node_ = nh;
    is_init_pose_ = false;
    work_state_ =  waiting;
    plan_target = target_A;
    cnt = 0;
    offb_set_mode.request.custom_mode = "OFFBOARD";
    arm_cmd.request.value = true;
    /*  Define the publisher of point and velocity.  */
    local_pos_pub_ = nh.advertise<geometry_msgs::PoseStamped>
            ("/mavros/setpoint_position/local", 10);
    speed_pub_ = nh.advertise<geometry_msgs::TwistStamped>
            ("/mavros/setpoint_velocity/cmd_vel", 10);

    /* Define the publisher of ours */
    servo_pub_ = nh.advertise<geometry_msgs::Vector3>("/sun/servo", 10);
    remap_pub_ = nh.advertise<std_msgs::String>("/sun/target_plan", 10);
    t265_ctl_pub_ = nh.advertise<std_msgs::Bool>("/sun/t265_ctl", 1);

    /*  Define the subscriber of UAV system or realsense. */
    vision_sub_ = nh.subscribe
            ("/mavros/vision_pose/pose", 10, &MavFsmNode::poseCallback, this);
    battery_sub_ =nh.subscribe("/mavros/battery", 1,&MavFsmNode::batCallback, this);
    state_sub_ = nh.subscribe
            ("/mavros/state", 10, &MavFsmNode::stateCallback, this);
    extended_state_sub_ = nh.subscribe
            ("/mavros/extended_state", 10, &MavFsmNode::extented_stateCallback, this);
    arming_client = nh.serviceClient
            <mavros_msgs::CommandBool>("/mavros/cmd/arming");
    set_mode_client= nh.serviceClient
            <mavros_msgs::SetMode>("/mavros/set_mode");

    /*  Define the mavros RC callback.*/
    rc_sub_ = nh.subscribe
            ("/mavros/rc/in", 10, &MavFsmNode::rcCallback, this);

    /*  Define the result of recognition */
    circle_sub_ = nh.subscribe
            ("/sun/circles", 10, &MavFsmNode::visionCallback, this);


/*  Get the parameters */
    nh.param<double>("/k_position/x",fp.k_position.x(),0.0);
    nh.param<double>("/k_position/y",fp.k_position.y(),0.0);
    nh.param<double>("/k_position/z",fp.k_position.z(),0.0);

    nh.param<double>("/k_velocity/x",fp.k_velocity.x(),0.0);
    nh.param<double>("/k_velocity/y",fp.k_velocity.y(),0.0);
    nh.param<double>("/k_velocity/z",fp.k_velocity.z(),0.0);
    nh.param<double>("/i_position/x",fp.i_position.x(),0.0);
    nh.param<double>("/i_position/y",fp.i_position.y(),0.0);
    nh.param<double>("/i_position/z",fp.i_position.z(),0.0);
    nh.param<double>("/k_thrust",fp.k_thrust,0.0);

    /* Define the std_circle_position */
    nh.param<double>("/std_circle_0/x",std_circle_position_0.x,0.0);
    nh.param<double>("/std_circle_0/y",std_circle_position_0.y,0.0);
    nh.param<double>("/std_circle_1/x",std_circle_position_1.x,0.0);
    nh.param<double>("/std_circle_1/y",std_circle_position_1.y,0.0);
    nh.param<double>("/std_circle_2/x",std_circle_position_2.x,0.0);
    nh.param<double>("/std_circle_2/y",std_circle_position_2.y,0.0);

    /* Define vel ctl mode param */
    nh.param<double>("/limit_vel_max/x", fp.limit_vel_max.x(), 0.0);
    nh.param<double>("/limit_vel_max/y", fp.limit_vel_max.y(), 0.0);
    nh.param<double>("/limit_vel_max/z", fp.limit_vel_max.z(), 0.0);
    nh.param<double>("/limit_vel_max/w", fp.limit_vel_max.w(), 0.0);

    /* tolerant of pose and velocity control*/
    nh.param<double>("/tolerance/vision/x", tolerance.vision_x, 0.1);
    nh.param<double>("/tolerance/vision/y", tolerance.vision_y, 0.1);
    nh.param<double>("/tolerance/pose/x", tolerance.pose_x, 0.2);
    nh.param<double>("/tolerance/pose/y", tolerance.pose_y, 0.2);
    nh.param<double>("/tolerance/pose/z", tolerance.pose_z, 0.2);
    nh.param<double>("/tolerance/angle/x", tolerance.angle_x, 0.1);
    nh.param<double>("/tolerance/angle/y", tolerance.angle_y, 0.1);
    nh.param<double>("/tolerance/angle/z", tolerance.angle_z, 0.1);
    nh.param<double>("/tolerance/angle/w", tolerance.angle_w, 0.1);

    nh.param<double>("/B_area/x", goalPose.B_pose.position.x, 0.0);
    nh.param<double>("/B_area/y", goalPose.B_pose.position.y, 0.0);
    nh.param<double>("/C_area/x", goalPose.C_pose.position.x, 0.0);
    nh.param<double>("/C_area/y", goalPose.C_pose.position.y, 0.0);

    /* Define if use 'target.yaml' data */
    nh.param<bool>("/B_area/if_use", if_use_yaml.if_use_B, 0.0);
    nh.param<bool>("/C_area/if_use", if_use_yaml.if_use_C, 0.0);

    /*  Waiting for the pose initialization  */
    while(!is_init_pose_){
        ros::spinOnce();
    }
    ROS_INFO("Complete position initialization!");
    memset(&land_signal_, 0 ,sizeof(land_signal_));

    goalPose.A_pose.position.x = 2.0;
    goalPose.A_pose.position.y = 0;
    goalPose.A_pose.position.z = 2.0;
    goalPose.B_pose.position.z = 2.0;
    goalPose.C_pose.position.z = 2.0;
    goalPose.H_pose.position.x = 0;
    goalPose.H_pose.position.y = 0;
    goalPose.H_pose.position.z = 2.0;

    servo_state.x = grasp_servo_A;
    servo_state.y = grasp_servo_B;
    servo_state.z = grasp_servo_C;
    servo_pub_.publish(servo_state);

    land_signal_.twist.linear.z = -0.3;
    land_signal_.twist.linear.x = 0;
    land_signal_.twist.linear.y = 0;
    takeoff_pose_.pose = init_pose_;
    takeoff_pose_.pose.position.z += 1;
    takeoff_pose_.header.frame_id = "body";
    target_pose_.pose.orientation = init_pose_.orientation;

    ROS_INFO("MAV INIT SUCCESS!");
    mav_fsm_ = node_.createTimer(ros::Duration(0.02), &MavFsmNode::main_FSM, this);
    ROS_INFO("INIT FSM TIMER SUCCESS!");
    ROS_INFO("Is timer started: %d", mav_fsm_.hasStarted());
}


