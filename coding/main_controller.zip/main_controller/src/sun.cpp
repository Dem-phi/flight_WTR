/*
 * @Author: Demphi
 * @Date: 2021-06-26 12:51:21
 * @Email: demphi339413361@outlook.com
 * @Function: Do not edit
 * @YouWant: add you want
 */
//#include "sun.h"
//using namespace sun;
//using namespace std;
//
//void MAV::update(){
//    if(cur_state){
//        cur_state->Execute(this);
//    }
//}
//void takeoff::JudgeTarget(MAV* mav){
//
//}
//void takeoff::StateEnter(MAV* mav){
//
//}
//
//void takeoff::Execute(MAV* mav){
//    mav->ChangeState(new pose);
//}
//
//void takeoff::StateExit(MAV* mav){
//
//}
#include "mav_fsm.h"
#include "math.h"
using namespace wtr;
using namespace std;
wtr::Aiming_height_level aiming_height_level;
#define is_plan_B true
#define over_obstacle_height_block 2.3
#define over_obstacle_height_circle 2.3
#define offload_test_times 300
#define poseMode_test_times 150

// ========================================== POSE_MODE =========================================
void MavFsmNode::pos_mode(){
    if(cnt++ > 50.0*mode_info_interval)// make the information frequency reduce to 1Hz.
    {
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][POSE]:-------------- \033[33m POSE CONTROL WORKING \033[0m-------------------");
    }
    target_pose_.header.frame_id="body";
    target_pose_.header.stamp = ros::Time::now();
/*    if(plan_target == detection){
        remap_target_state.data = "detection";
        target_pose_.pose = goalPose.detection_pose;
        goalPose.error_pose.position.x = goalPose.detection_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.detection_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.detection_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        test_times ++;
       if(L515Switch_on.data == true){
            L515Switch_pub_.publish(L515Switch_on);
            L515Switch_on.data = false;
        }
        if(test_times>=150){
            goalPose.detection_pose.position.y -= 0.2;
            if(is_obstacle_init_ || goalPose.detection_pose.position.y <= -1.3){
                ROS_INFO("Finish \033[34mdetection\033[0m, change to \033[34mtarget_A\033[0m.");
                local_pos_pub_.publish(target_pose_);
                plan_target = detection_finish;
                test_times = 0;
                return;
            }
            else{
                ROS_INFO("Fail to\033[34mdetect\033[0m, try another detecting point");
                test_times = 0;
                local_pos_pub_.publish(target_pose_);
                return;
            }
        }
//        local_pos_pub_.publish(target_pose_);
//        test_times++;
//        plan_target = detection_finish;
        return;
    }
    if(plan_target == detection){
        remap_target_state.data = "detection_finish";
        target_pose_.pose = goalPose.H_pose;
        goalPose.H_pose.position.z = 1.0;
        goalPose.error_pose.position.x = goalPose.H_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.H_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.H_pose.position.z-cur_pose_.position.z;
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        local_pos_pub_.publish(target_pose_);
        test_times = 0;
        plan_target = target_A;
    }*/
    if (plan_target == target_A){
        remap_target_state.data = "target_A";
        target_pose_.pose = goalPose.A_pose;
        goalPose.error_pose.position.x = goalPose.A_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.A_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.A_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        if(test_times <= poseMode_test_times){test_times++; return; }
        if(is_plan_B){
            if(circles_docker.x.data.size() == 0 && circles_docker.is_ready == true){
                circles_docker.is_ready = false;
                return;
            }
            else if(circles_docker.x.data.size() == 10 && circles_docker.is_ready == true){
                goalPose.A_pose.position.x = 0;
                goalPose.A_pose.position.y = 0;
                for(int i = 0; i < 10; i++){
                    goalPose.A_pose.position.x += circles_docker.x.data[i];
                    goalPose.A_pose.position.y += circles_docker.y.data[i];
                }
                goalPose.A_pose.position.x /= 10.0;
                goalPose.A_pose.position.y /= 10.0;
                ROS_INFO("Update A_position: %.2f, %.2f", goalPose.A_pose.position.x,goalPose.A_pose.position.y);
                circles_docker.x.data.clear();
                circles_docker.y.data.clear();
            }
            else{return;}
            ROS_INFO("Reach \033[34mtarget_B\033[0m, change to \033[34mtarget_B_2\033[0m.");
            test_times = 0;
            plan_target = target_A_2;
            return;
        }
    }
    else if(plan_target == target_A_2){
        remap_target_state.data = "target_A_2";
        target_pose_.pose = goalPose.A_pose;
        goalPose.error_pose.position.x = goalPose.A_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.A_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.A_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        if(is_plan_B){
            if(circles_docker.x.data.size() == 0 && circles_docker.is_ready == true){
                circles_docker.is_ready = false;
                return;
            }
            else if(circles_docker.x.data.size() == 10 && circles_docker.is_ready == true){
                goalPose.A_pose.position.x = 0;
                goalPose.A_pose.position.y = 0;
                for(int i = 0; i < 10; i++){
                    goalPose.A_pose.position.x += circles_docker.x.data[i];
                    goalPose.A_pose.position.y += circles_docker.y.data[i];
                }
                goalPose.A_pose.position.x /= 10.0;
                goalPose.A_pose.position.y /= 10.0;
                circles_docker.x.data.clear();
                circles_docker.y.data.clear();
            }
            else{return;}
            ROS_INFO("Reach \033[34mtarget_A_2\033[0m, change to \033[34mtarget_A_3\033[0m.");
            test_times = 0;
            plan_target = target_A_3;
            return;
        }
    }
    else if(plan_target == target_A_3){
        remap_target_state.data = "target_A_3";
        target_pose_.pose.position.y = goalPose.A_pose.position.y;
        target_pose_.pose.position.x = goalPose.A_pose.position.x + 0.11;
        target_pose_.pose.position.z = goalPose.A_pose.position.z;
        goalPose.error_pose.position.x = goalPose.A_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.A_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.A_pose.position.z-cur_pose_.position.z;
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        if(is_plan_B){
            ROS_INFO("Reach \033[34mtarget_A_3\033[0m, change to \033[34moffload_position\033[0m.");
            plan_target = offload_A;
            target_pose_.pose.position.z = offload_height;
            return;
        }
    }
/*    else if(plan_target == obstacle_rec){
        remap_target_state.data = "obstacle_rec";
        target_pose_.pose = goalPose.obstacle_rec_pose;
        goalPose.error_pose.position.x = target_pose_.pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = target_pose_.pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = target_pose_.pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x + 0.1 ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y + 0.1 ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        ROS_INFO("Reach \033[34mobstacle_rec\033[0m, move to \033[34mtarget_B\033[0m.");
        plan_target = target_B_ready;
        return
    }*/
    else if(plan_target == target_B_ready){
        remap_target_state.data = "target_B_ready";
        target_pose_.pose = goalPose.B_pose;
        target_pose_.pose.position.z = over_obstacle_height_block;
        goalPose.error_pose.position.x = target_pose_.pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = target_pose_.pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = target_pose_.pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        ROS_INFO("Reach \033[34motarget_B\033[0m, ready to \033[34mdown\033[0m.");
        plan_target = target_B;
        return;
    }
    else if(plan_target == target_B){
        remap_target_state.data = "target_B";
        target_pose_.pose = goalPose.B_pose;
        goalPose.error_pose.position.x = goalPose.B_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.B_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.B_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        if(is_plan_B){
            if(circles_docker.x.data.size() == 0 && circles_docker.is_ready == true){
                circles_docker.is_ready = false;
                return;
            }
            else if(circles_docker.x.data.size() == 10 && circles_docker.is_ready == true){
                goalPose.B_pose.position.x = 0;
                goalPose.B_pose.position.y = 0;
                for(int i = 0; i < 10; i++){
                    goalPose.B_pose.position.x += circles_docker.x.data[i];
                    goalPose.B_pose.position.y += circles_docker.y.data[i];
                }
                goalPose.B_pose.position.x /= 10.0;
                goalPose.B_pose.position.y /= 10.0;
                ROS_INFO("Update B_position: %.2f, %.2f", goalPose.B_pose.position.x,goalPose.B_pose.position.y);
                circles_docker.x.data.clear();
                circles_docker.y.data.clear();
            }
            else{return;}
            ROS_INFO("Reach \033[34mtarget_B\033[0m, change to \033[34mtarget_B_2\033[0m.");
            test_times = 0;
            plan_target = target_B_2;
            return;
        }
    }
    else if(plan_target == target_B_2){
        remap_target_state.data = "target_B_2";
        target_pose_.pose = goalPose.B_pose;
        goalPose.error_pose.position.x = goalPose.B_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.B_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.B_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        if(is_plan_B){
            if(circles_docker.x.data.size() == 0 && circles_docker.is_ready == true){
                circles_docker.is_ready = false;
                return;
            }
            else if(circles_docker.x.data.size() == 10 && circles_docker.is_ready == true){
                goalPose.B_pose.position.x = 0;
                goalPose.B_pose.position.y = 0;
                for(int i = 0; i < 10; i++){
                    goalPose.B_pose.position.x += circles_docker.x.data[i];
                    goalPose.B_pose.position.y += circles_docker.y.data[i];
                }
                goalPose.B_pose.position.x /= 10.0;
                goalPose.B_pose.position.y /= 10.0;
                circles_docker.x.data.clear();
                circles_docker.y.data.clear();
            }
            else{return;}
            ROS_INFO("Reach \033[34mtarget_B_2\033[0m, change to \033[34mtarget_B_3\033[0m.");
            test_times = 0;
            plan_target = target_B_3;
            return;
        }
    }
    else if(plan_target == target_B_3){
        remap_target_state.data = "target_B_3";
        target_pose_.pose.position.y = goalPose.B_pose.position.y - 0.11;
        target_pose_.pose.position.x = goalPose.B_pose.position.x + 0.04;
        target_pose_.pose.position.z = goalPose.B_pose.position.z ;
        goalPose.error_pose.position.x = goalPose.B_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.B_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.B_pose.position.z-cur_pose_.position.z;
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        if(is_plan_B){
            ROS_INFO("Reach \033[34mtarget_B_3\033[0m, change to \033[34moffload_position\033[0m.");
            plan_target = offload_B;
            target_pose_.pose.position.z = offload_height;
            return;
        }
    }
/*    else if(plan_target == obstacle_circle){
        remap_target_state.data = "obstacle_circle";
        target_pose_.pose = goalPose.obstacle_circle_pose;
        goalPose.error_pose.position.x = target_pose_.pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = target_pose_.pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = target_pose_.pose.position.z-cur_pose_.position.z;
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x + 0.1 ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y + 0.1 ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        ROS_INFO("Reach \033[34mobstacle_circle\033[0m, move to \033[34mtarget_C\033[0m.");
        plan_target = target_C_ready;
        return;
    }*/
    else if(plan_target == target_C_ready){
        remap_target_state.data = "target_C_ready";
        target_pose_.pose = goalPose.C_pose;
        target_pose_.pose.position.z = over_obstacle_height_circle;
        goalPose.error_pose.position.x = target_pose_.pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = target_pose_.pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = target_pose_.pose.position.z-cur_pose_.position.z;
        if(abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
           abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
           abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        ROS_INFO("Reach \033[34mtarget_C_ready\033[0m, ready to \033[34mdown\033[0m.");
        plan_target = target_C;
        return;
    }
    else if(plan_target == target_C){
        remap_target_state.data = "target_C";
        target_pose_.pose = goalPose.C_pose;
        goalPose.error_pose.position.x = goalPose.C_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.C_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.C_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        if(is_plan_B){
            if(circles_docker.x.data.size() == 0 && circles_docker.is_ready == true){
                circles_docker.is_ready = false;
                return;
            }
            else if(circles_docker.x.data.size() == 10 && circles_docker.is_ready == true){
                goalPose.C_pose.position.x = 0;
                goalPose.C_pose.position.y = 0;
                for(int i = 0; i < 10; i++){
                    goalPose.C_pose.position.x += circles_docker.x.data[i];
                    goalPose.C_pose.position.y += circles_docker.y.data[i];
                }
                goalPose.C_pose.position.x /= 10.0;
                goalPose.C_pose.position.y /= 10.0;
                circles_docker.x.data.clear();
                circles_docker.y.data.clear();
            }
            else{return;}
            ROS_INFO("Reach \033[34mtarget_C\033[0m, change to \033[34mtarget_C_2\033[0m.");
            test_times = 0;
            plan_target = target_C_2;
            return;
        }
    }
    else if(plan_target == target_C_2){
        remap_target_state.data = "target_C_2";
        target_pose_.pose = goalPose.C_pose;
        goalPose.error_pose.position.x = goalPose.C_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.C_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.C_pose.position.z-cur_pose_.position.z;
        local_pos_pub_.publish(target_pose_);
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z )
            return;
        if(test_times <= poseMode_test_times/2){test_times++; return; }
        if(is_plan_B){
            if(circles_docker.x.data.size() == 0 && circles_docker.is_ready == true){
                circles_docker.is_ready = false;
                return;
            }
            else if(circles_docker.x.data.size() == 10 && circles_docker.is_ready == true){
                goalPose.C_pose.position.x = 0;
                goalPose.C_pose.position.y = 0;
                for(int i = 0; i < 10; i++){
                    goalPose.C_pose.position.x += circles_docker.x.data[i];
                    goalPose.C_pose.position.y += circles_docker.y.data[i];
                }
                goalPose.C_pose.position.x /= 10.0;
                goalPose.C_pose.position.y /= 10.0;
                circles_docker.x.data.clear();
                circles_docker.y.data.clear();
            }
            else{return;}
            ROS_INFO("Reach \033[34mtarget_C_2\033[0m, change to \033[34mtarget_C_3\033[0m.");
            test_times = 0;
            plan_target = target_C_3;
            return;
        }
    }
    else if(plan_target == target_C_3){
        remap_target_state.data = "target_C_3";
        target_pose_.pose.position.x = goalPose.C_pose.position.x + 0.04;
        target_pose_.pose.position.y = goalPose.C_pose.position.y + 0.11;
        target_pose_.pose.position.z = goalPose.C_pose.position.z;
        goalPose.error_pose.position.x = goalPose.C_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.C_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.C_pose.position.z-cur_pose_.position.z;
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        if(is_plan_B){
            ROS_INFO("Reach \033[34mtarget_C_3\033[0m, change to \033[34moffload_position\033[0m.");
            plan_target = offload_C;
            target_pose_.pose.position.z = offload_height;
            return;
        }
    }
    else if(plan_target == back_ready){
        remap_target_state.data = "back_ready";
        target_pose_.pose = goalPose.H_pose;
        target_pose_.pose.position.z = over_obstacle_height_block;
        goalPose.error_pose.position.x = target_pose_.pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = target_pose_.pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = target_pose_.pose.position.z-cur_pose_.position.z;
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        local_pos_pub_.publish(target_pose_);
        ROS_INFO("flight is \033[34mready to land back\033[0m");
        plan_target = back;
        return;

    }
    else if(plan_target == back){
        remap_target_state.data = "back";
        target_pose_.pose = goalPose.H_pose;
        goalPose.error_pose.position.x = goalPose.H_pose.position.x-cur_pose_.position.x;
        goalPose.error_pose.position.y = goalPose.H_pose.position.y-cur_pose_.position.y;
        goalPose.error_pose.position.z = goalPose.H_pose.position.z-cur_pose_.position.z;
        if (abs(goalPose.error_pose.position.x)>tolerance.pose_x ||
            abs(goalPose.error_pose.position.y)>tolerance.pose_y ||
            abs(goalPose.error_pose.position.z)>tolerance.pose_z ){
            local_pos_pub_.publish(target_pose_);
            return;
        }
        ROS_INFO("flight is \033[34mback\033[0m");
        work_state_ = land;

    }
    else if(plan_target == offload_A){
        remap_target_state.data = "offload_A";
        local_pos_pub_.publish(target_pose_);
        if( abs(cur_pose_.position.x - target_pose_.pose.position.x) > tolerance.pose_x ||
            abs(cur_pose_.position.y - target_pose_.pose.position.y) > tolerance.pose_y ||
            abs(cur_pose_.position.z - target_pose_.pose.position.z) > tolerance.pose_z )
            return;
        test_times++;
        if(test_times >= offload_test_times/3){
            takeoff_pose_.pose = cur_pose_; // position at A
            plan_target = target_A;
            work_state_ = land;
            test_times = 0;
        }
        return;
    }
    else if(plan_target == offload_B){
        remap_target_state.data = "offload_B";
        local_pos_pub_.publish(target_pose_);
        if( abs(cur_pose_.position.x - target_pose_.pose.position.x) > tolerance.pose_x ||
            abs(cur_pose_.position.y - target_pose_.pose.position.y) > tolerance.pose_y ||
            abs(cur_pose_.position.z - target_pose_.pose.position.z) > tolerance.pose_z )
            return;
        test_times++;
        if(test_times >= offload_test_times/2){
            takeoff_pose_.pose = cur_pose_; // position at B
            plan_target = target_B;
            work_state_ = land;
            test_times = 0;
        }
        return;
    }
    else if(plan_target == offload_C){
        remap_target_state.data = "offload_C";
        local_pos_pub_.publish(target_pose_);
        if( abs(cur_pose_.position.x - target_pose_.pose.position.x) > tolerance.pose_x ||
            abs(cur_pose_.position.y - target_pose_.pose.position.y) > tolerance.pose_y ||
            abs(cur_pose_.position.z - target_pose_.pose.position.z) > tolerance.pose_z )
            return;
        test_times++;
        if(test_times >= offload_test_times/2){
            takeoff_pose_.pose = cur_pose_; // position at B
            plan_target = target_C;
            work_state_ = land;
            test_times = 0;
        }
        return;
    }
}

// ========================================== VELOCITY_MODE =========================================
void MavFsmNode::vel_mode() {
    if (cnt++ > 50.0*mode_info_interval){
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][VELOCITY]:-------------- \033[33m VELOCITY CONTROL WORKING \033[0m-------------------");
    }
    vel_signal_.header.stamp = ros::Time::now();
    vel_signal_.header.frame_id = "body";
    speed_pub_.publish(vel_signal_);
/*    if (abs(different_vector[0]) < tolerance.vision_x && abs(different_vector[1]) < tolerance.vision_y){
        test_times++;
        if(test_times > 10){ //stay 0.5 seconds
            test_times = 0;
            if(plan_target == target_A){
                // switch variable is current level
                switch (aiming_height_level.index)
                {
                case 0:
                {
                    aiming_height_level.next_level();
                    ROS_INFO("Aiming level changes to %f", aiming_height_level.level());
                    target_pose_.pose = cur_pose_;
                    target_pose_.pose.position.z = aiming_height_level.level();
                    temp_target = target_A;
                    plan_target = aiming_level;
                    work_state_ = pose;
                    break;
                }
                case 1:
                {
//                    aiming_height_level.next_level();
//                    ROS_INFO("Aiming level changes to %f", aiming_height_level.level());
//                    target_pose_.pose = cur_pose_;
//                    target_pose_.pose.position.z = aiming_height_level.level();
//                    plan_target = aiming_level;
//                    temp_target = target_A;
//                    work_state_ = pose;
//                    break;

                    aiming_height_level.back();
                    ROS_INFO("Plan to land A");
                    work_state_ = land;
                    plan_target = target_A;
                    //target_pose_.pose = cur_pose_;
                    //temp_target = target_A;
                    break;
                }
                case 2:
                {
                    if(work_state_ == PID_debug)
                        return;
                    aiming_height_level.back();
                    ROS_INFO("Plan to land A");
                    work_state_ = land;
                    plan_target = target_A;
                    //target_pose_.pose = cur_pose_;
                    //temp_target = target_A;
                    break;
                }
                default:{ROS_INFO("\033[31m[Error] Unexpected case when aiming\033[0m"); break;}}
                return;
            }
            else if(plan_target == target_B){
                switch_on.data = true;
                B_confirm_pub_.publish(switch_on);
                // switch variable is current level
                switch (aiming_height_level.index)
                {
                case 0:
                {
                    aiming_height_level.next_level();
                    ROS_INFO("Aiming level changes to %f", aiming_height_level.level());
                    target_pose_.pose = cur_pose_;
                    target_pose_.pose.position.z = aiming_height_level.level();
                    plan_target = aiming_level;
                    temp_target = target_B;
                    work_state_ = pose;
                    break;
                }
                case 1:
                {
                    aiming_height_level.back();
                    ROS_INFO("Plan to land B");
                    work_state_ = land;
                    plan_target = target_B;
                    //target_pose_.pose = cur_pose_;
                    //temp_target = target_A;
                    break;
                }
                default:{ROS_INFO("[Error] Unexpected case when aiming!"); break;}}
                return;
            }
            else if (plan_target == target_C){
                switch_on.data = true;
                B_confirm_pub_.publish(switch_on);
                // switch variable is current level
                switch (aiming_height_level.index)
                {
                case 0:
                {
                    aiming_height_level.next_level();
                    ROS_INFO("Aiming level changes to %f", aiming_height_level.level());
                    target_pose_.pose = cur_pose_;
                    target_pose_.pose.position.z = aiming_height_level.level();
                    plan_target = aiming_level;
                    temp_target = target_C;
                    work_state_ = pose;
                    break;
                }
                case 1:
                {
                    aiming_height_level.back();
                    ROS_INFO("Plan to land C");
                    work_state_ = land;
                    plan_target = target_C;
                    //target_pose_.pose = cur_pose_;
                    //temp_target = target_A;
                    break;
                }
                default:{ROS_INFO("[Error] Unexpected case when aiming!"); break;}}
                return;
            }
        }
    }*/
/*    if(plan_target == obstacle_rec){

    }
    else if(plan_target == target_B_ready){

    }
    else if(plan_target == obstacle_circle){

    }
    else if(plan_target == target_C_ready){

    }*/

}

// ========================================== TAKEOFF_MODE =========================================
void MavFsmNode::takeoff_mode() {
    if(cnt++ > 50.0*mode_info_interval){
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][TAKEOFF]:--------------\033[36m TAKEOFF \033[0m-------------------");
    }
    takeoff_pose_.header.stamp = ros::Time::now();
    switch (plan_target) {
        case target_A:{
            /*            goalPose.error_pose.position.x = cur_pose_.position.x - takeoff_pose_.pose.position.x;
            goalPose.error_pose.position.y = cur_pose_.position.y - takeoff_pose_.pose.position.y;
            goalPose.error_pose.position.z = cur_pose_.position.z - takeoff_pose_.pose.position.z;*/
            local_pos_pub_.publish(takeoff_pose_);
/*            if (abs(goalPose.error_pose.position.x) > tolerance.pose_x ||
                abs(goalPose.error_pose.position.y) > tolerance.pose_y ||
                abs(goalPose.error_pose.position.z) > tolerance.pose_z)
                return;
            test_times++;
            if(test_times >= 50){
                local_pos_pub_.publish(takeoff_pose_);
                ROS_INFO("Plan to \033[34mdetect both obstacle\033[0m");
                work_state_ = pose;
                break;
            }*/
            break;
        }
        case target_A_UP: {
            takeoff_pose_.pose.position.z = over_obstacle_height_block;
            goalPose.error_pose.position.x = cur_pose_.position.x - takeoff_pose_.pose.position.x;
            goalPose.error_pose.position.y = cur_pose_.position.y - takeoff_pose_.pose.position.y;
            goalPose.error_pose.position.z = cur_pose_.position.z - takeoff_pose_.pose.position.z;
            local_pos_pub_.publish(takeoff_pose_);
            if (abs(goalPose.error_pose.position.x) > tolerance.pose_x ||
                abs(goalPose.error_pose.position.y) > tolerance.pose_y ||
                abs(goalPose.error_pose.position.z) > tolerance.pose_z)
                return;
            test_times++;
            if(test_times >= 50){
                local_pos_pub_.publish(takeoff_pose_);
                ROS_INFO("Plan to \033[34mobstacle rectangle\033[0m");
                test_times = 0;
                plan_target = target_B_ready;
                work_state_ = pose;
                goalPose.obstacle_rec_pose.position.x = goalPose.obstacle_rec_pose.position.x - 2.0 + cur_pose_.position.x;
                goalPose.obstacle_rec_pose.position.y = goalPose.obstacle_rec_pose.position.y - 0.0 + cur_pose_.position.y;
                break;
            }
            break;
        }
        case target_B_UP: {
            takeoff_pose_.pose.position.z = over_obstacle_height_circle;
            goalPose.error_pose.position.x = cur_pose_.position.x - takeoff_pose_.pose.position.x;
            goalPose.error_pose.position.y = cur_pose_.position.y - takeoff_pose_.pose.position.y;
            goalPose.error_pose.position.z = cur_pose_.position.z - takeoff_pose_.pose.position.z;
            local_pos_pub_.publish(takeoff_pose_);
            if (abs(goalPose.error_pose.position.x) > tolerance.pose_x ||
                abs(goalPose.error_pose.position.y) > tolerance.pose_y ||
                abs(goalPose.error_pose.position.z) > tolerance.pose_z)
                return;
            test_times++;
            if(test_times >= 50){
                local_pos_pub_.publish(takeoff_pose_);
                ROS_INFO("Plan to \033[34mobstacle circle\033[0m");
                test_times = 0;
                plan_target = target_C_ready;
                work_state_ = pose;
                break;
            }
            break;
        }
        case target_C_UP: {
            takeoff_pose_.pose.position.z = over_obstacle_height_block;
            goalPose.error_pose.position.x = cur_pose_.position.x - takeoff_pose_.pose.position.x;
            goalPose.error_pose.position.y = cur_pose_.position.y - takeoff_pose_.pose.position.y;
            goalPose.error_pose.position.z = cur_pose_.position.z - takeoff_pose_.pose.position.z;
            local_pos_pub_.publish(takeoff_pose_);
            if (abs(goalPose.error_pose.position.x) > tolerance.pose_x ||
                abs(goalPose.error_pose.position.y) > tolerance.pose_y ||
                abs(goalPose.error_pose.position.z) > tolerance.pose_z)
                return;
            ROS_INFO("Plan to \033[34mback\033[0m");
            plan_target = back_ready;
            work_state_ = pose;
            break;
        }
    }
}

// ========================================== LAND_MODE =========================================
void MavFsmNode::land_mode() {
    if(cnt++ > 50.0*mode_info_interval){
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][LAND]:--------------\033[32m LANDING \033[0m-------------------");
    }
    land_signal_.header.stamp = ros::Time::now();
    land_signal_.header.frame_id = "body";
    if (rc_msg_land_ < 1100){
        land_signal_.twist.linear.z = -0.3;
        speed_pub_.publish(land_signal_);
        return;
    }
    if(rc_msg_land_ > 1100){
        test_times++;
        switch (plan_target){
            case target_A: {
                land_signal_.twist.linear.z = -0.5;
                if(test_times >= 1 && if_on_ground==1){
                    servo_state.y = release_servo_B;
                    servo_pub_.publish(servo_state);
                }
                if(test_times>=100 && if_on_ground==1) {
                    takeoff_pose_.pose = cur_pose_; // position at A
                    takeoff_pose_.pose.position.x -= 0.1;
                    plan_target = target_A_UP;
                    work_state_ = takeoff;
                    test_times = 0;
                }
                break;
            }
            case target_B: {
                land_signal_.twist.linear.z = -0.5;
                if(test_times >= 1 && if_on_ground==1){
                    servo_state.x = release_servo_A;
                    servo_pub_.publish(servo_state);
                }
                if(test_times>=100 && if_on_ground==1) {
                    takeoff_pose_.pose = cur_pose_; // position at B
                    plan_target = target_B_UP;
                    work_state_ = takeoff;
                    test_times=0;
                }
                break;
            }
            case target_C: {
                land_signal_.twist.linear.z = -0.5;
                if(test_times >= 1 && if_on_ground==1){
                    servo_state.z = release_servo_C;
                    servo_pub_.publish(servo_state);
                }
                if(test_times>=100 && if_on_ground==1) {
                    takeoff_pose_.pose = cur_pose_; // position at C
                    plan_target = target_C_UP;
                    work_state_ = takeoff;
                    test_times=0;
                }
                break;
            }
            case back:{
                land_signal_.twist.linear.z = -0.5;
                if(if_on_ground == 1){
                    work_state_ = waiting;
                }
                break;
            }
        }
    }
    speed_pub_.publish(land_signal_);
    return;
}

// ========================================== WAIT_MODE =========================================
void MavFsmNode::wait_mode() {
    if(cnt++ > 50.0*mode_info_interval)// make the information frequency reduce to 1Hz.
    {
        cnt=0;
        ROS_INFO("[WTR MAV MAIN FSM][WAITING]:--------------Waiting for command.-------------------");
    }
}

// Returns the circle's position and culculate a PID velocity
void MavFsmNode::visionCallback(const geometry_msgs::Vector3::ConstPtr &msg){
    circle_position.x = msg->x;
    circle_position.y = msg->y;

    vel_signal_.twist.linear.z = 0;
    if(plan_target == target_A || plan_target == target_B || plan_target == target_C || plan_target == aiming_level)
    {
        different_z[0] = aiming_height_level.level() - cur_pose_.position.z;
        vel_signal_.twist.linear.z = 1.0*different_z[0] + 0.5*different_z[1]*0.02;
        different_z[1] = different_z[0];
    }
    switch (aiming_height_level.index)
    {
        case 0:{
            circle_position.x = 245;
            circle_position.y = 175;
            different_vector[0] = circle_position.x - std_circle_position_0.x;
            different_vector[1] = circle_position.y - std_circle_position_0.y;
        }
        case 1:{
            circle_position.x = 270;
            circle_position.y = 100;
            different_vector[0] = circle_position.x - std_circle_position_1.x;
            different_vector[1] = circle_position.y - std_circle_position_1.y;
        }
        case 2:{
            circle_position.x = 260;
            circle_position.y = 202;
            different_vector[0] = circle_position.x - std_circle_position_2.x;
            different_vector[1] = circle_position.y - std_circle_position_2.y;
        }
    }

/*  Define the position PID */
    vel_signal_.twist.linear.x = fp.k_position.x()*different_vector[0]-fp.i_position.x()*different_vector[2]*0.02+fp.k_velocity.x()*(different_vector[0] - different_vector[2])/0.02;
    vel_signal_.twist.linear.y = fp.k_position.y()*different_vector[1]-fp.i_position.y()*different_vector[3]*0.02+fp.k_velocity.y()*(different_vector[1] - different_vector[3])/0.02;
    vel_signal_.twist.linear.x /= 800.0;
    vel_signal_.twist.linear.y /= -800.0;

    different_vector[4] = different_vector[2];
    different_vector[5] = different_vector[3];
    different_vector[2] = different_vector[0];
    different_vector[3] = different_vector[1];

    /* limit the max velocity */
    if(vel_signal_.twist.linear.x >= fp.limit_vel_max.x()){
        vel_signal_.twist.linear.x = fp.limit_vel_max.x();
    }
    else if(vel_signal_.twist.linear.x <= -fp.limit_vel_max.x())
    {
        vel_signal_.twist.linear.x = -fp.limit_vel_max.x();
    }
    if(vel_signal_.twist.linear.y >= fp.limit_vel_max.y()){
        vel_signal_.twist.linear.y = fp.limit_vel_max.y();
    }
    else if(vel_signal_.twist.linear.y <= -fp.limit_vel_max.y())
    {
        vel_signal_.twist.linear.y = -fp.limit_vel_max.y();
    }

    vel_signal_.twist.angular.x = 0;
    vel_signal_.twist.angular.y = 0;
    vel_signal_.twist.angular.z = 0;
}

// main loop func
void MavFsmNode::main_FSM(const ros::TimerEvent &) {
    if(!is_init_pose_) work_state_ = waiting;
    if(rc_msg_land_<1100){
        work_state_ = land;
        land_signal_.twist.linear.z = -0.3;
        speed_pub_.publish(land_signal_);
        return;
    }
    if(rc_msg_land_>1100 && change_state_times++>250 && if_on_ground == 1 && plan_target == target_A){
        if(cur_state.mode!="OFFBOARD"){
            if(set_mode_client.call(offb_set_mode)&&
               offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enable");
            }
        }
        else if(!cur_state.armed){
            if( arming_client.call(arm_cmd) &&
                arm_cmd.response.success){
                ROS_INFO("Flight armed");
            }
        }
        change_state_times=0;
    }
    switch (work_state_){
        case waiting: {
            wait_mode();break;
        }
        case takeoff: {
            takeoff_mode();break;
        }
        case land: {
            land_mode();break;
        }
        case pose:{
            pos_mode();
            remap_pub_.publish(remap_target_state);
            break;
        }
        case velocity:{
            vel_mode();break;
        }
        case PID_debug:{
            plan_target = target_A;
            vel_mode();break;
        }
        default:{
            wait_mode();
        }
    }
}

void MavFsmNode::poseCallback(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    if(!is_init_pose_){
        init_pose_ = msg->pose;
        is_init_pose_ = true;
    }
    //protect
    if(msg->pose.position.z>2.5){
        work_state_ = land;
    }
    if(is_init_pose_){
        cur_pose_=msg->pose;
    }
}

void MavFsmNode::rcCallback(const mavros_msgs::RCInConstPtr &msg) {
    rc_msg_land_ = msg->channels[6];
    if(msg->channels[6] < 1100){    // C开关向上 降落
        work_state_ = land;
    }
    else if(msg->channels[6] > 1800){ //
        work_state_ = PID_debug;
    }
    else if(msg->channels[5] < 1500){ // 开关B向上
        work_state_= takeoff;
    }
    else if (msg -> channels[5] > 1500 && msg->channels[5] < 1800){ // 开关Bid 使用位姿控制
        if (work_state_ == takeoff && plan_target == target_A){
            work_state_ = pose;
        }
    }
}

void MavFsmNode::imuCallback(const sensor_msgs::ImuConstPtr &imu_msg) {
    feedback.cPositionDD = Vec3(imu_msg->linear_acceleration.x,
                                imu_msg->linear_acceleration.y,
                                imu_msg->linear_acceleration.z);
}

void MavFsmNode::odomCallback(const nav_msgs::OdometryConstPtr &odom_msg) {
    feedback.cPositionD = Vec3(
            odom_msg->twist.twist.linear.x,
            odom_msg->twist.twist.linear.y,
            odom_msg->twist.twist.linear.z
    );
    feedback.cPosition = Vec3(
            odom_msg->pose.pose.position.x,
            odom_msg->pose.pose.position.y,
            odom_msg->pose.pose.position.z
    );
}

void MavFsmNode::batCallback(const sensor_msgs::BatteryStateConstPtr &msg){
    if(msg->voltage<=16.0 && v_cnt >=50){
        ROS_INFO("Battery voltage is %.2f", msg->voltage);
        v_cnt = 0;
    }
    v_cnt++;
}

void MavFsmNode::extented_stateCallback(const mavros_msgs::ExtendedStateConstPtr &msg){
    if_on_ground = msg->landed_state;
}

void MavFsmNode::stateCallback(const mavros_msgs::StateConstPtr &msg) {
    cur_state = *msg;
}

/*void MavFsmNode::rgbdCallback(const std_msgs::Float32MultiArray::ConstPtr &msg){
    if(!if_use_yaml.if_use_rec){
        goalPose.obstacle_rec_pose.position.x = msg->data[0];
        goalPose.obstacle_rec_pose.position.y = msg->data[1];
    }
    if(!if_use_yaml.if_use_circle){
        goalPose.obstacle_circle_pose.position.x = msg->data[3];
        goalPose.obstacle_circle_pose.position.y = msg->data[4];
    }
    is_obstacle_init_ = true;
    ROS_INFO("Finish detection\t obstacle_rec: %.2f,%.2f\t obstacle_circle: %.2f,%.2f",
             goalPose.obstacle_rec_pose.position.x,
             goalPose.obstacle_rec_pose.position.y,
             goalPose.obstacle_circle_pose.position.x,
             goalPose.obstacle_circle_pose.position.y);
}*/

void MavFsmNode::realworldCallback(const std_msgs::Float32MultiArray::ConstPtr &msg){
    float x,y;
    x = msg->data[0] + cur_pose_.position.x;
    y = msg->data[1] + cur_pose_.position.y;
    cout << x << " " << y << endl;
//    if(plan_target == target_B){
//        realworld_offload_points.rw_B.x = x;
//        realworld_offload_points.rw_B.y = y;
//    }
//    else if(plan_target == target_C){
//        realworld_offload_points.rw_C.x = x;
//        realworld_offload_points.rw_C.y = y;
//    }
    if(!circles_docker.is_ready){
        circles_docker.x.data.push_back(x);
        circles_docker.y.data.push_back(y);
        if(circles_docker.x.data.size() == 10){
            circles_docker.is_ready = true;
        }
        return;
    }
}

// main func: initialize the parameters and start the timer
MavFsmNode::MavFsmNode(ros::NodeHandle &nh) {
    node_ = nh;
    is_init_pose_ = false;
    work_state_ =  waiting;
    plan_target = target_A;
    cnt = 0;
    L515Switch_on.data = true;
    offb_set_mode.request.custom_mode = "OFFBOARD";
    arm_cmd.request.value = true;
    /*  Define the pulisher of point and velocity.  */
    local_pos_pub_ = nh.advertise<geometry_msgs::PoseStamped>
            ("/mavros/setpoint_position/local", 10);
    speed_pub_ = nh.advertise<geometry_msgs::TwistStamped>
            ("/mavros/setpoint_velocity/cmd_vel", 10);
    B_confirm_pub_ = nh.advertise<std_msgs::Bool>("/sun/rec_switch", 10);
    L515Switch_pub_ = nh.advertise<std_msgs::Bool>("/sun/L515_switch", 10);
    servo_pub_ = nh.advertise<geometry_msgs::Vector3>("/sun/servo", 10);
    remap_pub_ = nh.advertise<std_msgs::String>("/sun/target_plan", 10);
    /*  Define the subscriber of mocap system or realsense. */
    vision_sub_ = nh.subscribe
            ("/mavros/vision_pose/pose", 10, &MavFsmNode::poseCallback, this);
/*    rgbd_sub_ = nh.subscribe
            ("/sun/obstacle_position", 10, &MavFsmNode::rgbdCallback, this);*/
    realworld_points_sub_ = nh.subscribe
            ("/sun/RelativeRealworldCircles", 10, &MavFsmNode::realworldCallback, this);
    odom_sub_ = nh.subscribe(
            "/mavros/local_position/odom",10,&MavFsmNode::odomCallback,this);
    imu_sub_ = nh.subscribe(
            "/mavros/imu/data",10,&MavFsmNode::imuCallback,this);
    battery_sub_ =nh.subscribe("/mavros/battery", 1,&MavFsmNode::batCallback, this);
    /*  Define the mavros RC callback.*/
    rc_sub_ = nh.subscribe
            ("/mavros/rc/in", 10, &MavFsmNode::rcCallback, this);
    /*  Define the result of recognition */
    circle_sub_ = nh.subscribe
            ("/sun/circles", 10, &MavFsmNode::visionCallback, this);
/*    rec_sub_ = nh.subscribe
            ("/sun/recognition_result", 10, &MavFsmNode::rec_resultCallback, this);*/
    /* state of flight*/
    state_sub_ = nh.subscribe
            ("/mavros/state", 10, &MavFsmNode::stateCallback, this);
    extended_state_sub_ = nh.subscribe
            ("/mavros/extended_state", 10, &MavFsmNode::extented_stateCallback, this);
    arming_client = nh.serviceClient
            <mavros_msgs::CommandBool>("/mavros/cmd/arming");
    set_mode_client= nh.serviceClient
            <mavros_msgs::SetMode>("/mavros/set_mode");

/*  Get the parameters */
    nh.param<double>("/k_position/x",fp.k_position.x(),0.0);
    nh.param<double>("/k_position/y",fp.k_position.y(),0.0);
    nh.param<double>("/k_position/z",fp.k_position.z(),0.0);

    nh.param<double>("/k_velocity/x",fp.k_velocity.x(),0.0);
    nh.param<double>("/k_velocity/y",fp.k_velocity.y(),0.0);
    nh.param<double>("/k_velocity/z",fp.k_velocity.z(),0.0);
    nh.param<double>("/i_position/x",fp.i_position.x(),0.0);
    nh.param<double>("/i_position/y",fp.i_position.y(),0.0);
    nh.param<double>("/i_position/z",fp.i_position.z(),0.0);
    nh.param<double>("/k_thrust",fp.k_thrust,0.0);

    /* Define the std_circle_position */
    nh.param<double>("/std_circle_0/x",std_circle_position_0.x,0.0);
    nh.param<double>("/std_circle_0/y",std_circle_position_0.y,0.0);
    nh.param<double>("/std_circle_1/x",std_circle_position_1.x,0.0);
    nh.param<double>("/std_circle_1/y",std_circle_position_1.y,0.0);
    nh.param<double>("/std_circle_2/x",std_circle_position_2.x,0.0);
    nh.param<double>("/std_circle_2/y",std_circle_position_2.y,0.0);

    /* Define vel ctl mode param */
    nh.param<double>("/limit_vel_max/x", fp.limit_vel_max.x(), 0.0);
    nh.param<double>("/limit_vel_max/y", fp.limit_vel_max.y(), 0.0);
    nh.param<double>("/limit_vel_max/z", fp.limit_vel_max.z(), 0.0);
    nh.param<double>("/limit_vel_max/w", fp.limit_vel_max.w(), 0.0);

    /* tolerant of pose and velocity control*/
    nh.param<double>("/tolerance/vision/x", tolerance.vision_x, 0.1);
    nh.param<double>("/tolerance/vision/y", tolerance.vision_y, 0.1);
    nh.param<double>("/tolerance/pose/x", tolerance.pose_x, 0.2);
    nh.param<double>("/tolerance/pose/y", tolerance.pose_y, 0.2);
    nh.param<double>("/tolerance/pose/z", tolerance.pose_z, 0.2);
    nh.param<double>("/tolerance/angle/x", tolerance.angle_x, 0.1);
    nh.param<double>("/tolerance/angle/y", tolerance.angle_y, 0.1);
    nh.param<double>("/tolerance/angle/z", tolerance.angle_z, 0.1);
    nh.param<double>("/tolerance/angle/w", tolerance.angle_w, 0.1);

/*    nh.param<double>("/detection/x", goalPose.detection_pose.position.x, 0.0);
    nh.param<double>("/detection/y", goalPose.detection_pose.position.y, 0.0);*/
    nh.param<double>("/obstacle_rec/x", goalPose.obstacle_rec_pose.position.x, 0.0);
    nh.param<double>("/obstacle_rec/y", goalPose.obstacle_rec_pose.position.y, 0.0);
    nh.param<double>("/obstacle_circle/x", goalPose.obstacle_circle_pose.position.x, 0.0);
    nh.param<double>("/obstacle_circle/y", goalPose.obstacle_circle_pose.position.y, 0.0);
    nh.param<double>("/B_area/x", goalPose.B_pose.position.x, 0.0);
    nh.param<double>("/B_area/y", goalPose.B_pose.position.y, 0.0);
    nh.param<double>("/C_area/x", goalPose.C_pose.position.x, 0.0);
    nh.param<double>("/C_area/y", goalPose.C_pose.position.y, 0.0);

    /* Define if use 'target.yaml' data */
/*    nh.param<bool>("/detection/if_use", if_use_yaml.if_use_detection, 0.0);*/
    nh.param<bool>("/obstacle_rec/if_use", if_use_yaml.if_use_rec, 0.0);
    nh.param<bool>("/B_area/if_use", if_use_yaml.if_use_B, 0.0);
    nh.param<bool>("/obstacle_circle/if_use", if_use_yaml.if_use_circle, 0.0);
    nh.param<bool>("/C_area/if_use", if_use_yaml.if_use_C, 0.0);

    /*  Waiting for the pose initialization  */
    while(!is_init_pose_){
        ros::spinOnce();
    }
    ROS_INFO("Complete position initialization!");
    memset(&land_signal_, 0 ,sizeof(land_signal_));
    // STANDARD(x,y) = (2,2.2)
/*    goalPose.detection_pose.position.z = 0.4;*/

    goalPose.A_pose.position.x = 2;
    goalPose.A_pose.position.y = 0;
    goalPose.A_pose.position.z = 0.525;

    goalPose.obstacle_rec_pose.position.z = over_obstacle_height_block;

    goalPose.B_pose.position.z = 0.525;

    goalPose.obstacle_circle_pose.position.z = over_obstacle_height_circle;

    goalPose.C_pose.position.z = 0.525;

    goalPose.H_pose.position.x = 0;
    goalPose.H_pose.position.y = 0;
    goalPose.H_pose.position.z = 0.5;

    servo_state.x = grasp_servo_A;
    servo_state.y = grasp_servo_B;
    servo_state.z = grasp_servo_C;
    servo_pub_.publish(servo_state);

    land_signal_.twist.linear.z = -0.3;
    land_signal_.twist.linear.x = 0;
    land_signal_.twist.linear.y = 0;
    takeoff_pose_.pose = init_pose_;
    takeoff_pose_.pose.position.z += 1;
    takeoff_pose_.header.frame_id = "body";

    /* real world offload points */
    offload_height = 0.10;
    realworld_offload_points.rw_A.x = 2.0;
    realworld_offload_points.rw_A.y = 0.0;
    realworld_offload_points.rw_A.z = offload_height;
    realworld_offload_points.rw_B.x = goalPose.B_pose.position.x;
    realworld_offload_points.rw_B.y = goalPose.B_pose.position.y;
    realworld_offload_points.rw_B.z = offload_height;
    realworld_offload_points.rw_C.x = goalPose.C_pose.position.x;
    realworld_offload_points.rw_C.y = goalPose.C_pose.position.y;
    realworld_offload_points.rw_C.z = offload_height;

    target_pose_.pose.orientation = init_pose_.orientation;

    ROS_INFO("MAV INIT SUCCESS!");
    mav_fsm_ = node_.createTimer(ros::Duration(0.02), &MavFsmNode::main_FSM, this);
    ROS_INFO("INIT FSM TIMER SUCCESS!");
    ROS_INFO("Is timer started: %d", mav_fsm_.hasStarted());
}


